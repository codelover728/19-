# _*_ coding: utf-8 _*_
__author__ = 'XiaoDong-Hu and Huanli-Xu'
__date__ = '2017/4/30 16:01'


pri = {'+': 1, '-': 1,
      '*': 2, '/': 2,
      '\0': 0
      }

class Stack:
    """模拟栈"""
    def __init__(self):
        self.items = []

    def isEmpty(self):
        return len(self.items)==0

    def push(self, item):
        self.items.append(item)

    def pop(self):
        return self.items.pop()

    def top(self):
        if not self.isEmpty():
            return self.items[len(self.items)-1]

    def size(self):
        return len(self.items)

    def printf(self):
        for i in self.items:
            print i

def readNumber(str, currentIndex):
    int_num = 0
    decimal_num = 0.0
    intCount = 0
    decimalCount = 0
    currentIndex1 = 0
    for i in range(currentIndex, len(str)):
        if str[i] < '0' or str[i] > '9':
            currentIndex1 = i
            break
        intCount = intCount + 1
    for i in range(currentIndex, currentIndex + intCount):
        index = currentIndex + intCount - i - 1
        times = 10**(index)
        digit = int(str[i]) * times
        int_num += digit

    if str[currentIndex1] == '.':
        for i in range(currentIndex1 + 1, len(str)):
            if str[i] < '0' and str[i] > '9':
                break
            decimalCount = decimalCount + 1
        for i in range(currentIndex + 1, currentIndex + 1 + decimalCount):
            digit = int(str[i]) * 1/(10^(currentIndex + decimalCount - i))
            decimal_num += digit
        return int_num + decimal_num
    else:
        return int_num

def Calculating(infixStr):
    opnd = Stack()
    optr = Stack()

    optr.push('\0')
    infixStr = infixStr + '\0'
    i = 0
    while not optr.isEmpty():
        if infixStr[i] >= '0' and infixStr[i] <= '9':
            number = readNumber(infixStr, i)
            opnd.push(number)
            i = i + len(str(number)) -1
        else:
            if pri[infixStr[i]] > pri[optr.top() ]:
                optr.push(infixStr[i])
            elif pri[infixStr[i]] <= pri[optr.top()] and optr.top() != '\0':
                opr2 = float(opnd.top())
                opnd.pop()
                opr1 = opnd.top()
                opnd.pop()
                if optr.top() == '+':
                    op = opr1 + opr2
                    opnd.push(op)
                    opnd.printf()
                if optr.top() == '-':
                    op = opr1 - opr2
                    opnd.push(op)
                if optr.top() == '*':
                    op = opr1 * opr2
                    opnd.push(op)
                if optr.top() == '/':
                    op = opr1 / opr2
                    opnd.push(op)
                optr.pop()
                i = i - 1
            else:
                optr.pop()
        i = i + 1

    print opnd.top()
    return opnd.top()




