# _*_ coding: utf-8 _*_
__author__ = 'XiaoDong-Hu and Huanli-Xu'
__date__ = '2017/4/30 9:03'

import sys
import os

import math

from PyQt5 import QtWidgets, QtGui, QtCore

import Calculating
import Random_question
import Question_write
import Question_read


class Button(QtWidgets.QToolButton):
    def __init__(self, text, parent=None):
        super(Button, self).__init__(parent)

        self.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Preferred)
        self.setText(text)

    def sizeHint(self):
        size = super(Button, self).sizeHint()
        size.setHeight(size.height() + 20)
        size.setWidth(max(size.width(), size.height()))
        return size


class Calculator(QtWidgets.QWidget):

    def __init__(self, parent=None):
        super(Calculator, self).__init__(parent)


        self.predStr = ""
        self.succStr = ""
        self.questionSum = 0
        self.correctCount = 0
        self.correctPercent = 0
        self.fraction_list = []
        self.errorQuestionList = []
        self.lastQuestionList = []
        self.index = 3




        global lcd
        lcd = QtWidgets.QTextBrowser()
        lcd.setFixedHeight(60)
        lcd.setFont(QtGui.QFont("Microsoft YaHei", 20))
        lcd.setText('0'.decode('utf-8'))

        global lcd_correct_answer
        lcd_correct_answer = QtWidgets.QTextBrowser()
        lcd_correct_answer.setFixedHeight(40)
        lcd_correct_answer.setFont(QtGui.QFont("Microsoft YaHei", 13))
        lcd_correct_answer.setText("".decode('utf-8'))

        global lcd_correct_percent
        lcd_correct_percent = QtWidgets.QTextBrowser()
        lcd_correct_percent.setFixedHeight(40)
        lcd_correct_percent.setFont(QtGui.QFont("Microsoft YaHei", 13))
        lcd_correct_percent.setText("".decode('utf-8'))

        global lcd_question_sum
        lcd_question_sum = QtWidgets.QTextBrowser()
        lcd_question_sum.setFixedHeight(40)
        lcd_question_sum.setFont(QtGui.QFont("Microsoft YaHei", 13))
        lcd_question_sum.setText("".decode('utf-8'))

        global lcd_correct_count
        lcd_correct_count = QtWidgets.QTextBrowser()
        lcd_correct_count.setFixedHeight(40)
        lcd_correct_count.setFont(QtGui.QFont("Microsoft YaHei", 13))
        lcd_correct_count.setText('0'.decode('utf-8'))

        self.intButton = QtWidgets.QRadioButton(u"整数运算")
        self.fractionButton = QtWidgets.QRadioButton(u"分数数运算")
        self.lastErrorQuestionButton = QtWidgets.QRadioButton(u"上次记录")

        self.backspaceButton = self.createButton(u"退格", self.backspaceClicked)
        self.clearAllButton = self.createButton(u"清除", self.clearAll)

        self.start = self.createButton(u"开始", self.start)
        self.next_question = self.createButton(u"下一题", self.next_question)

        self.label1 = QtWidgets.QLabel(u'请输入答案')
        self.label2 = QtWidgets.QLabel(u'正确答案')
        self.label3 = QtWidgets.QLabel(u'正确率')
        self.label4 = QtWidgets.QLabel(u'当前题目数量')
        self.label5 = QtWidgets.QLabel(u'答对数目')
        self.submitButton = self.createButton(u"提交", self.submit_answer)
        self.inputLabel = QtWidgets.QLineEdit(u'')
        font = self.inputLabel.font()
        font.setPointSize(font.pointSize() + 8)
        self.inputLabel.setFixedHeight(40)
        self.inputLabel.setFont(font)



        mainLayout = QtWidgets.QGridLayout()
        mainLayout.setSizeConstraint(QtWidgets.QLayout.SetFixedSize)

        mainLayout.addWidget(lcd, 0, 0, 1, 8)
        mainLayout.addWidget(self.intButton, 1, 0, 1, 2)
        mainLayout.addWidget(self.fractionButton, 1, 3, 1, 2)
        mainLayout.addWidget(self.lastErrorQuestionButton, 1, 6, 1, 2)

        mainLayout.addWidget(self.backspaceButton, 2, 0, 1, 4)
        mainLayout.addWidget(self.clearAllButton, 2, 4, 1, 4)

        mainLayout.addWidget(self.start, 3, 0, 1, 4)
        mainLayout.addWidget(self.next_question, 3, 4, 1, 4)

        mainLayout.addWidget(self.label1, 4, 0, 1, 2)
        mainLayout.addWidget(self.inputLabel, 4, 2, 1, 2)
        mainLayout.addWidget(self.submitButton, 4, 4, 1, 4)

        mainLayout.addWidget(self.label2, 5, 0, 1, 2)
        mainLayout.addWidget(lcd_correct_answer, 5, 2, 1, 2)
        mainLayout.addWidget(self.label3, 5, 4, 1, 2)
        mainLayout.addWidget(lcd_correct_percent, 5, 6, 1, 2)

        mainLayout.addWidget(self.label4, 6, 0, 1, 2)
        mainLayout.addWidget(lcd_question_sum, 6, 2, 1, 2)
        mainLayout.addWidget(self.label5, 6, 4, 1, 2)
        mainLayout.addWidget(lcd_correct_count,6, 6, 1, 2)

        self.setLayout(mainLayout)
        self.setWindowTitle(u"随机出题计算器   (注：保留小数点后1位)")

        if os.path.exists('store.txt'):
            self.lastQuestionList = Question_read.question_read()
            lcd_correct_percent.setText(self.lastQuestionList[0] + "%")
            lcd_question_sum.setText(self.lastQuestionList[1])
            lcd_correct_count.setText(self.lastQuestionList[2])

    def closeEvent(self, event):
        reply = QtWidgets.QMessageBox.question(self, '确认退出', '你确定要退出么？',
                                               QtWidgets.QMessageBox.Yes,
                                               QtWidgets.QMessageBox.No
                                               )
        if reply == QtWidgets.QMessageBox.Yes:
            self.errorQuestionList.insert(0, str(self.correctPercent))
            self.errorQuestionList.insert(1, str(self.questionSum))
            self.errorQuestionList.insert(2, str(self.correctCount))
            Question_write.question_write(self.errorQuestionList)
            event.accept()
        else:
            event.ignore()

    def createButton(self, text, member):
        button = Button(text)
        button.clicked.connect(member)  # member = SLOT(函数名)
        return button

    def onplay_int(self):
        self.predStr = ""
        self.predStr = Random_question.Random_int_question()
        lcd.setText(self.predStr)

    def onplay_fraction(self):
        self.predStr = ""
        self.succStr = ""
        self.fraction_list = Random_question.Random_fraction_question()
        self.predStr = self.fraction_list[0]

        lcd.setText(self.predStr)

    def backspaceClicked(self):
        self.predStr = self.predStr[0:len(self.predStr) - 1]
        if len(self.predStr) == 0:
            lcd.setText('0'.decode('utf-8'))
        lcd.setText(self.predStr)

    def showMessage(self, str):
        qm = QtWidgets.QMessageBox
        meaasge_box = qm(qm.warning, str)
        meaasge_box.exec_()


    def clearAll(self):
        self.predStr = ""
        self.succStr = ""
        lcd.setText('0'.decode('utf-8'))


    def start(self):
        self.questionSum += 1
        lcd_question_sum.setText(str(self.questionSum))
        lcd_correct_count.setText(str(self.correctCount))
        lcd_correct_percent.setText(str(self.correctPercent) + "%")
        if self.intButton.isChecked():
            self.onplay_int()
        if self.fractionButton.isChecked():
            self.onplay_fraction()
        if self.lastErrorQuestionButton.isChecked():
            self.lastQuestionList = Question_read.question_read()
            lcd.setText(self.lastQuestionList[self.index])
            self.index += 1


    def next_question(self):
        self.questionSum += 1
        self.inputLabel.setText("")
        lcd_question_sum.setText(str(self.questionSum))
        lcd_correct_answer.setText("")
        lcd_correct_count.setText(str(self.correctCount))
        lcd_correct_percent.setText(str(self.correctPercent) + "%")
        if self.intButton.isChecked():
            self.onplay_int()
        if self.fractionButton.isChecked():
            self.onplay_fraction()
        if self.lastErrorQuestionButton.isChecked():
            if self.index < len(self.lastQuestionList):
                lcd.setText(self.lastQuestionList[self.index])
                self.index += 1
            else:
                self.showMessage("The questions are done!")

    def submit_answer(self):
        self.succStr = ""
        input_str = self.inputLabel.text()
        print input_str
        if self.intButton.isChecked():
            input_dec = float(input_str)
            result = round(Calculating.Calculating(self.predStr), 1)
            self.succStr = str(result)
            if input_dec == result:
                self.correctCount += 1
            else:
                self.errorQuestionList.append(self.predStr)
            self.correctPercent = round(self.correctCount / (1.0 * self.questionSum) * 100, 2)
            lcd_correct_count.setText(str(self.correctCount))
            lcd_correct_answer.setText(self.succStr)
            lcd_correct_percent.setText(str(self.correctPercent) + "%")
        if self.fractionButton.isChecked():
            self.succStr = str(self.fraction_list[1])
            if input_str == str(self.fraction_list[1]):
                self.correctCount += 1
            self.correctPercent = round(self.correctCount / (1.0 * self.questionSum) * 100, 2)
            lcd_correct_count.setText(str(self.correctCount))
            lcd_correct_answer.setText(str(self.fraction_list[1]))
            lcd_correct_percent.setText(str(self.correctPercent) + "%")

if __name__ == '__main__':
    import sys
    app = QtWidgets.QApplication(sys.argv)
    calc = Calculator()
    calc.show()
    sys.exit(app.exec_())