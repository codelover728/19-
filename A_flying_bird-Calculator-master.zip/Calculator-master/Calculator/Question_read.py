# _*_ coding: utf-8 _*_
__author__ = 'XiaoDong-Hu and Huanli-Xu'
__date__ = '2017/5/7 15:29'


import os


def question_read():
    lastQuestionList = []
    with open('store.txt', 'r') as f:
       for item in f.readlines():
           item = item[0:len(item) - 1]
           lastQuestionList.append(item)
    f.close()
    return lastQuestionList