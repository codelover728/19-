# _*_ coding: utf-8 _*_
__author__ = 'XiaoDong-Hu and Huanli-Xu'
__date__ = '2017/5/7 15:29'

import os


def question_write(errorList):
    with open('store.txt', 'w') as f:
        for item in errorList:
            item = item + '\n'
            f.write(item)
    f.close()