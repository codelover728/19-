# _*_ coding: utf-8 _*_
__author__ = 'XiaoDong-Hu and Huanli-Xu'
__date__ = '2017/5/6 20:26'


import random
from fractions import Fraction

# if __name__ == '__main__':
def Random_int_question():
    oprator_list = ['', '+', '-', '*', '/']
    num_size = random.randint(3, 4)
    opr_size = num_size - 1
    question_str = ""
    i = 0
    while i < num_size:
        question_str += str(random.randint(1, 15)) + str(oprator_list[random.randint(1, 4)])
        i = i + 1
    question_str = question_str[0: len(question_str) - 1]
    return question_str
    # print question_str


def Random_fraction_question():
    oprator_list = ['', '+', '-', '*', '/']
    num_size = 2
    question_str = ""
    question_list = []
    i = 0
    opr_num = []
    oprator = []
    while i < num_size:
        f = Fraction(random.randint(1, 15), random.randint(1, 15))
        opr_num.append(f)
        oprator.append(oprator_list[random.randint(1, 4)])
        if f.numerator >= f.denominator:
            int_num = f.numerator / f.denominator
            numerator = f.numerator % f.denominator
            question_str += str(int_num) + "\'" + str(numerator) + '/' + str(f.denominator) + " " + str(oprator[i]) + " "
        else:
            question_str  += str(f) + " " +str(oprator[i]) + " "
        i = i + 1
    question_str = question_str[0: len(question_str) - 2] #减去多出的运算符的长度以及最后一个空格的长度
    if oprator[0] == '+':
        answer = opr_num[0] + opr_num[1]
    elif oprator[0] == '-':
        answer = opr_num[0] - opr_num[1]
    elif oprator[0] == '*':
        answer = opr_num[0] * opr_num[1]
    else:
        answer = opr_num[0] / opr_num[1]
    print answer
    if answer.numerator >= answer.denominator:
        answer_ = str(answer.numerator/answer.denominator) + "\'" + str(answer.numerator%answer.denominator) + "/" + str(answer.denominator)
        question_list.append(question_str)
        question_list.append(answer_)

    question_list.append(question_str)
    question_list.append(answer)
    return question_list


